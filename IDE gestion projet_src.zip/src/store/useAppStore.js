﻿import { useEffect, useState } from "react";
import { loadProjects, saveProjects } from "../services/storage";
import { createEmptyProject } from "../services/projectFactory";
import { downloadJsonFile, readJsonFile } from "../services/jsonTransfer";
import {
  projectToMarkdown,
  downloadMarkdownFile,
} from "../services/markdownExport";

function newBacklogId() {
  return `b_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
}

function newJournalId() {
  return `j_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
}


export function useAppStore() {
  const [projects, setProjects] = useState([]);
  const [currentProjectId, setCurrentProjectId] = useState(null);
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    const loaded = loadProjects();
    setProjects(loaded);
    if (loaded.length > 0) {
      setCurrentProjectId(loaded[0].project.id);
    }
    setIsHydrated(true);
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    saveProjects(projects);
  }, [projects, isHydrated]);

  function createProject() {
    const newProject = createEmptyProject();
    setProjects((prev) => [newProject, ...prev]);
    setCurrentProjectId(newProject.project.id);
  }

  function openProject(projectId) {
    setCurrentProjectId(projectId);
  }

  function deleteProject(projectId) {
    setProjects((prev) => prev.filter((p) => p.project.id !== projectId));
    setCurrentProjectId((prev) => (prev === projectId ? null : prev));
  }

  function updateProjectMeta(projectId, patch) {
    setProjects((prev) =>
      prev.map((p) =>
        p.project.id === projectId
          ? {
              ...p,
              project: {
                ...p.project,
                ...patch,
                updatedAt: new Date().toISOString(),
              },
            }
          : p
      )
    );
  }

  function updateStageField(projectId, stageKey, field, value) {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.project.id !== projectId) return p;

        return {
          ...p,
          project: {
            ...p.project,
            updatedAt: new Date().toISOString(),
          },
          stages: {
            ...p.stages,
            [stageKey]: {
              ...p.stages[stageKey],
              [field]: value,
            },
          },
        };
      })
    );
  }

  function addBacklogItem(projectId, item) {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.project.id !== projectId) return p;

        const backlogItem = {
          id: newBacklogId(),
          createdAt: new Date().toISOString(),
          ...item,
        };

        return {
          ...p,
          project: {
            ...p.project,
            updatedAt: new Date().toISOString(),
          },
          backlog: [backlogItem, ...p.backlog],
        };
      })
    );
  }


function addJournalEntry(projectId, entry) {
  setProjects((prev) =>
    prev.map((p) => {
      if (p.project.id !== projectId) return p;

      const journalEntry = {
        id: newJournalId(),
        createdAt: new Date().toISOString(),
        ...entry,
      };

      return {
        ...p,
        project: {
          ...p.project,
          updatedAt: new Date().toISOString(),
        },
        journal: [journalEntry, ...(p.journal || [])],
      };
    })
  );
}



  function updateBacklogItemStatus(projectId, itemId, status) {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.project.id !== projectId) return p;

        return {
          ...p,
          project: {
            ...p.project,
            updatedAt: new Date().toISOString(),
          },
          backlog: p.backlog.map((item) =>
            item.id === itemId ? { ...item, status } : item
          ),
        };
      })
    );
  }

  function exportCurrentProjectJson() {
    const project = projects.find((p) => p.project.id === currentProjectId);
    if (!project) return;

    const slug = project.project.slug || project.project.title || "project";
    const safeSlug = slug.toLowerCase().replace(/\s+/g, "-");

    downloadJsonFile(`${safeSlug}.json`, project);
  }

  async function importProjectFromFile(file) {
    const importedProject = await readJsonFile(file);

    if (!importedProject?.project?.id) {
      throw new Error("Le fichier importé ne contient pas de projet valide.");
    }

    const importedId = importedProject.project.id;

    setProjects((prev) => {
      const filtered = prev.filter((p) => p.project.id !== importedId);
      return [
        {
          ...importedProject,
          project: {
            ...importedProject.project,
            updatedAt: new Date().toISOString(),
          },
        },
        ...filtered,
      ];
    });

    setCurrentProjectId(importedId);
  }

  function exportCurrentProjectMarkdown() {
    const project = projects.find((p) => p.project.id === currentProjectId);
    if (!project) return;

    const slug = project.project.slug || project.project.title || "project";
    const safeSlug = slug.toLowerCase().replace(/\s+/g, "-");
    const markdown = projectToMarkdown(project);

    downloadMarkdownFile(`${safeSlug}.md`, markdown);
  }

  const currentProject =
    projects.find((p) => p.project.id === currentProjectId) ?? null;

  return {
    projects,
    currentProject,
    currentProjectId,
    createProject,
    openProject,
    deleteProject,
    updateProjectMeta,
    updateStageField,
    addBacklogItem,
    addJournalEntry,
    updateBacklogItemStatus,
    exportCurrentProjectJson,
    importProjectFromFile,
    exportCurrentProjectMarkdown,
  };
}