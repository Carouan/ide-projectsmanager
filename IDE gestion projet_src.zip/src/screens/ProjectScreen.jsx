import { useRef, useState } from "react";
import StageEditor from "../components/StageEditor";
import BacklogPanel from "../components/BacklogPanel";
import JournalPanel from "../components/JournalPanel";

export default function ProjectScreen({
  projectDoc,
  onBack,
  onUpdateProjectMeta,
  onUpdateStageField,
  onAddBacklogItem,
  onUpdateBacklogItemStatus,
  onAddJournalEntry,
  onExportJson,
  onImportJson,
  onExportMarkdown,
}) {
  const [tab, setTab] = useState("project");
  const fileInputRef = useRef(null);

  if (!projectDoc) {
    return (
      <div className="page-shell">
        <div className="page-container">
          <button className="btn btn-secondary" onClick={onBack}>
            ← Retour
          </button>
          <div className="empty-state">
            <h2>Aucun projet sélectionné</h2>
            <p>Reviens à la liste puis ouvre un projet.</p>
          </div>
        </div>
      </div>
    );
  }

  const { project, stages, backlog, journal } = projectDoc;
  const stage = stages.v0_0;

  async function handleImportChange(event) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await onImportJson(file);
    } catch (error) {
      alert(error.message);
    } finally {
      event.target.value = "";
    }
  }

  return (
    <div className="page-shell">
      <div className="page-container">
        <div className="topbar">
          <button className="btn btn-secondary" onClick={onBack}>
            ← Retour
          </button>

          <div className="topbar-meta">
            <span className="badge">{project.currentStage}</span>
            <span className="muted">
              Dernière mise à jour :{" "}
              {new Date(project.updatedAt).toLocaleString()}
            </span>
          </div>
        </div>

        <section className="hero hero-project">
          <div>
            <div className="eyebrow">Projet</div>
            <h1>{project.title}</h1>
            <p className="hero-text">{project.summary}</p>
          </div>

          <div className="project-actions">
            <button className="btn btn-secondary" onClick={onExportJson}>
              Export JSON
            </button>

            <button
              className="btn btn-secondary"
              onClick={() => fileInputRef.current?.click()}
            >
              Import JSON
            </button>

            <button className="btn btn-primary" onClick={onExportMarkdown}>
              Export Markdown
            </button>

            <input
              ref={fileInputRef}
              type="file"
              accept=".json,application/json"
              style={{ display: "none" }}
              onChange={handleImportChange}
            />
          </div>
        </section>

        <div className="tabs">
          <button
            className={`tab ${tab === "project" ? "tab-active" : ""}`}
            onClick={() => setTab("project")}
          >
            Projet
          </button>
          <button
            className={`tab ${tab === "stage" ? "tab-active" : ""}`}
            onClick={() => setTab("stage")}
          >
            Étape v0.0
          </button>
          <button
            className={`tab ${tab === "backlog" ? "tab-active" : ""}`}
            onClick={() => setTab("backlog")}
          >
            Backlog
          </button>
          <button
            className={`tab ${tab === "journal" ? "tab-active" : ""}`}
            onClick={() => setTab("journal")}
          >
            Journal
          </button>
        </div>

        {tab === "project" && (
          <section className="panel">
            <h2>Métadonnées du projet</h2>

            <div className="form-grid">
              <label className="field">
                <span>Titre</span>
                <input
                  value={project.title}
                  onChange={(e) =>
                    onUpdateProjectMeta(project.id, { title: e.target.value })
                  }
                />
              </label>

              <label className="field field-full">
                <span>Résumé</span>
                <textarea
                  rows={4}
                  value={project.summary}
                  onChange={(e) =>
                    onUpdateProjectMeta(project.id, { summary: e.target.value })
                  }
                />
              </label>

              <label className="field field-full">
                <span>Description</span>
                <textarea
                  rows={6}
                  value={project.description}
                  onChange={(e) =>
                    onUpdateProjectMeta(project.id, {
                      description: e.target.value,
                    })
                  }
                />
              </label>
            </div>
          </section>
        )}

        {tab === "stage" && (
          <StageEditor
            projectId={project.id}
            stageKey="v0_0"
            stage={stage}
            onUpdateStageField={onUpdateStageField}
          />
        )}

        {tab === "backlog" && (
          <BacklogPanel
            projectId={project.id}
            backlog={backlog}
            onAddBacklogItem={onAddBacklogItem}
            onUpdateBacklogItemStatus={onUpdateBacklogItemStatus}
          />
        )}
        {tab === "journal" && (
          <JournalPanel
            projectId={project.id}
            journal={journal}
            onAddJournalEntry={onAddJournalEntry}
          />
        )}
      </div>
    </div>
  );
}