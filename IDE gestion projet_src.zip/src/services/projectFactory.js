export function createEmptyProject() {
  const now = new Date().toISOString();

  return {
    schemaVersion: "1.0",
    project: {
      id: crypto.randomUUID(),
      slug: "nouveau-projet",
      title: "Nouveau projet",
      summary: "Résumé à compléter",
      description: "",
      status: "active",
      createdAt: now,
      updatedAt: now,
      tags: [],
      owner: "Sébastien",
      currentStage: "v0_0",
    },
    stages: {
      v0_0: {
        version: "v.0.0",
        title: "Idée initiale",
        status: "todo",
        goal: "",
        notes: "",
        deliverable: "",
        definitionOfDone: "",
        linkedBacklogIds: [],
        linkedJournalIds: [],
      },
    },
    backlog: [],
    journal: [],
    decisions: [],
    attachments: [],
    settings: {
      theme: "dark",
      autosave: true,
      exportFormat: "markdown",
    },
  };
}
