﻿export default function StageEditor({
  projectId,
  stageKey,
  stage,
  onUpdateStageField,
}) {
  if (!stage) {
    return (
      <section className="panel">
        <h2>Etape introuvable</h2>
      </section>
    );
  }

  return (
    <section className="panel">
      <div className="panel-header">
        <div>
          <h2>{stage.title}</h2>
          <p className="muted">Édition de l'étape {stage.version}</p>
        </div>
        <span className="badge">{stage.status}</span>
      </div>

      <div className="form-grid">
        <label className="field">
          <span>Statut</span>
          <select
            value={stage.status}
            onChange={(e) =>
              onUpdateStageField(projectId, stageKey, "status", e.target.value)
            }
          >
            <option value="todo">todo</option>
            <option value="in_progress">in_progress</option>
            <option value="blocked">blocked</option>
            <option value="done">done</option>
          </select>
        </label>

        <label className="field field-full">
          <span>Objectif</span>
          <textarea
            rows={3}
            value={stage.goal}
            onChange={(e) =>
              onUpdateStageField(projectId, stageKey, "goal", e.target.value)
            }
          />
        </label>

        <label className="field field-full">
          <span>Notes</span>
          <textarea
            rows={6}
            value={stage.notes}
            onChange={(e) =>
              onUpdateStageField(projectId, stageKey, "notes", e.target.value)
            }
          />
        </label>

        <label className="field field-full">
          <span>Livrable</span>
          <textarea
            rows={4}
            value={stage.deliverable}
            onChange={(e) =>
              onUpdateStageField(
                projectId,
                stageKey,
                "deliverable",
                e.target.value
              )
            }
          />
        </label>

        <label className="field field-full">
          <span>Definition of Done</span>
          <textarea
            rows={4}
            value={stage.definitionOfDone}
            onChange={(e) =>
              onUpdateStageField(
                projectId,
                stageKey,
                "definitionOfDone",
                e.target.value
              )
            }
          />
        </label>
      </div>
    </section>
  );
}
