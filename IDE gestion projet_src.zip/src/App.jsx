﻿import { useState } from "react";
import { useAppStore } from "./store/useAppStore";
import ProjectListScreen from "./screens/ProjectListScreen";
import ProjectScreen from "./screens/ProjectScreen";

export default function App() {
  const {
    projects,
    currentProject,
    createProject,
    openProject,
    deleteProject,
    updateProjectMeta,
    updateStageField,
    addBacklogItem,
    addJournalEntry,
    updateBacklogItemStatus,
    exportCurrentProjectJson,
    importProjectFromFile,
    exportCurrentProjectMarkdown,
  } = useAppStore();

  const [view, setView] = useState("list");

  function handleCreateProject() {
    createProject();
    setView("project");
  }

  function handleOpenProject(projectId) {
    openProject(projectId);
    setView("project");
  }

  function handleBack() {
    setView("list");
  }

  return view === "list" ? (
    <ProjectListScreen
      projects={projects}
      onCreateProject={handleCreateProject}
      onOpenProject={handleOpenProject}
      onDeleteProject={deleteProject}
    />
  ) : (
    <ProjectScreen
      projectDoc={currentProject}
      onBack={handleBack}
      onUpdateProjectMeta={updateProjectMeta}
      onUpdateStageField={updateStageField}
      onAddBacklogItem={addBacklogItem}
      onAddJournalEntry={addJournalEntry}
      onUpdateBacklogItemStatus={updateBacklogItemStatus}
      onExportJson={exportCurrentProjectJson}
      onImportJson={importProjectFromFile}
      onExportMarkdown={exportCurrentProjectMarkdown}
    />
  );
}